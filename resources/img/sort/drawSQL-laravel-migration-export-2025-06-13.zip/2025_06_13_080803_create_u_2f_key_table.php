<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('u_2f_key', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->string('name');
            $table->integer('user_id');
            $table->foreign('user_id')->references('id')->on('users');
            $table->string('keyHandle');
            $table->string('publicKey')->unique();
            $table->text('certificate');
            $table->integer('counter');
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('u_2f_key');
    }
};
