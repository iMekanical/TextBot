<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('statistics', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('number_of_users');
            $table->integer('number_of_contacts');
            $table->integer('number_of_notes');
            $table->integer('number_of_oauth_access_tokens');
            $table->integer('number_of_oauth_clients');
            $table->integer('number_of_offsprings');
            $table->integer('number_of_progenitors');
            $table->integer('number_of_relationships');
            $table->integer('number_of_subscriptions');
            $table->integer('number_of_reminders');
            $table->integer('number_of_tasks');
            $table->integer('number_of_kids');
            $table->integer('number_of_activities');
            $table->integer('number_of_addresses');
            $table->integer('number_of_api_calls');
            $table->integer('number_of_calls');
            $table->integer('number_of_contact_fields');
            $table->integer('number_of_contact_field_types');
            $table->integer('number_of_debts');
            $table->integer('number_of_entries');
            $table->integer('number_of_gifts');
            $table->integer('number_of_invitations_sent')->nullable();
            $table->integer('number_of_accounts_with_more_than_one_user')->nullable();
            $table->integer('number_of_tags')->nullable();
            $table->integer('number_of_import_jobs')->nullable();
            $table->integer('number_of_conversations')->nullable();
            $table->integer('number_of_messages')->nullable();
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('statistics');
    }
};
