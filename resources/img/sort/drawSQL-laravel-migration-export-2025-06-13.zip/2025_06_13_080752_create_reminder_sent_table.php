<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('reminder_sent', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('account_id');
            $table->foreign('account_id')->references('id')->on('accounts');
            $table->integer('reminder_id')->nullable();
            $table->foreign('reminder_id')->references('id')->on('reminders');
            $table->integer('user_id');
            $table->foreign('user_id')->references('id')->on('users');
            $table->date('planned_date');
            $table->dateTime('sent_date');
            $table->string('nature');
            $table->string('frequency_type')->nullable();
            $table->integer('frequency_number')->nullable();
            $table->longText('html_content')->nullable();
            $table->longText('text_content')->nullable();
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('reminder_sent');
    }
};
