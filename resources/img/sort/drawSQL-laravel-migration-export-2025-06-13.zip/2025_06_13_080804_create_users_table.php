<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('users', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->string('first_name');
            $table->string('last_name');
            $table->string('email')->unique();
            $table->integer('me_contact_id')->nullable();
            $table->foreign('me_contact_id')->references('id')->on('contacts');
            $table->tinyInteger('admin');
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('remember_token')->nullable();
            $table->string('google2fa_secret')->nullable();
            $table->integer('account_id');
            $table->foreign('account_id')->references('id')->on('accounts');
            $table->string('timezone')->nullable();
            $table->integer('currency_id')->nullable();
            $table->foreign('currency_id')->references('id')->on('currencies');
            $table->string('locale');
            $table->string('metric');
            $table->string('fluid_container');
            $table->string('contacts_sort_order');
            $table->string('name_order');
            $table->integer('invited_by_user_id')->nullable();
            $table->foreign('invited_by_user_id')->references('id')->on('users');
            $table->string('dashboard_active_tab');
            $table->string('gifts_active_tab');
            $table->string('profile_active_tab');
            $table->tinyInteger('profile_new_life_event_badge_seen');
            $table->string('temperature_scale')->nullable();
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
