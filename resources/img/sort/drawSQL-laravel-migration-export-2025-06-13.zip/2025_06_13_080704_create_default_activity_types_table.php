<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('default_activity_types', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('default_activity_type_category_id');
            $table->foreign('default_activity_type_category_id')->references('id')->on('default_activity_type_categories');
            $table->string('translation_key');
            $table->string('location_type');
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('default_activity_types');
    }
};
