<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('contact_tag', function (Blueprint $table) {
            $table->integer('contact_id');
            $table->foreign('contact_id')->references('id')->on('contacts');
            $table->integer('tag_id');
            $table->foreign('tag_id')->references('id')->on('tags');
            $table->integer('account_id');
            $table->foreign('account_id')->references('id')->on('accounts');
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('contact_tag');
    }
};
