<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('life_event_types', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('account_id');
            $table->foreign('account_id')->references('id')->on('accounts');
            $table->integer('life_event_category_id');
            $table->foreign('life_event_category_id')->references('id')->on('life_event_categories');
            $table->string('name');
            $table->string('default_life_event_type_key')->nullable();
            $table->tinyInteger('core_monica_data');
            $table->text('specific_information_structure')->nullable();
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('life_event_types');
    }
};
