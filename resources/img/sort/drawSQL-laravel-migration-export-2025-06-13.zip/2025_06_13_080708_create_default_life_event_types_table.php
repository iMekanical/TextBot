<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('default_life_event_types', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('default_life_event_category_id');
            $table->foreign('default_life_event_category_id')->references('id')->on('default_life_event_categories');
            $table->string('translation_key');
            $table->text('specific_information_structure')->nullable();
            $table->tinyInteger('migrated');
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('default_life_event_types');
    }
};
