<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('import_jobs', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('account_id');
            $table->foreign('account_id')->references('id')->on('accounts');
            $table->integer('user_id');
            $table->foreign('user_id')->references('id')->on('users');
            $table->string('type');
            $table->integer('contacts_found')->nullable();
            $table->integer('contacts_skipped')->nullable();
            $table->integer('contacts_imported')->nullable();
            $table->string('filename')->nullable();
            $table->date('started_at')->nullable();
            $table->date('ended_at')->nullable();
            $table->tinyInteger('failed');
            $table->mediumText('failed_reason')->nullable();
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('import_jobs');
    }
};
