<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('metadata_love_relationships', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('account_id');
            $table->foreign('account_id')->references('id')->on('accounts');
            $table->integer('relationship_id');
            $table->foreign('relationship_id')->references('id')->on('relationships');
            $table->tinyInteger('is_active');
            $table->mediumText('notes')->nullable();
            $table->dateTime('meet_date')->nullable();
            $table->dateTime('official_date')->nullable();
            $table->dateTime('breakup_date')->nullable();
            $table->mediumText('breakup_reason')->nullable();
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('metadata_love_relationships');
    }
};
