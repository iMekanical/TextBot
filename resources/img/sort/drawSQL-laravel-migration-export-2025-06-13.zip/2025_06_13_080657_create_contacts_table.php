<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('contacts', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->integer('account_id');
            $table->foreign('account_id')->references('id')->on('accounts');
            $table->string('first_name');
            $table->string('middle_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('nickname')->nullable();
            $table->integer('gender_id')->nullable();
            $table->foreign('gender_id')->references('id')->on('genders');
            $table->string('description')->nullable();
            $table->char('uuid')->nullable();
            $table->tinyInteger('is_starred');
            $table->tinyInteger('is_partial');
            $table->tinyInteger('is_active');
            $table->tinyInteger('is_dead');
            $table->integer('deceased_special_date_id')->nullable();
            $table->integer('deceased_reminder_id')->nullable();
            $table->date('last_talked_to')->nullable();
            $table->integer('stay_in_touch_frequency')->nullable();
            $table->dateTime('stay_in_touch_trigger_date')->nullable();
            $table->integer('birthday_special_date_id')->nullable();
            $table->integer('birthday_reminder_id')->nullable();
            $table->integer('first_met_through_contact_id')->nullable();
            $table->integer('first_met_special_date_id')->nullable();
            $table->integer('first_met_reminder_id')->nullable();
            $table->string('first_met_where')->nullable();
            $table->longText('first_met_additional_info')->nullable();
            $table->string('job')->nullable();
            $table->string('company')->nullable();
            $table->longText('food_preferences')->nullable();
            $table->string('avatar_source');
            $table->string('avatar_gravatar_url')->nullable();
            $table->char('avatar_adorable_uuid')->nullable();
            $table->string('avatar_adorable_url')->nullable();
            $table->string('avatar_default_url')->nullable();
            $table->integer('avatar_photo_id')->nullable();
            $table->tinyInteger('has_avatar');
            $table->string('avatar_external_url')->nullable();
            $table->string('avatar_file_name')->nullable();
            $table->string('avatar_location');
            $table->string('gravatar_url')->nullable();
            $table->timestamp('last_consulted_at')->nullable();
            $table->integer('number_of_views');
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
            $table->string('default_avatar_color');
            $table->tinyInteger('has_avatar_bool');
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('contacts');
    }
};
