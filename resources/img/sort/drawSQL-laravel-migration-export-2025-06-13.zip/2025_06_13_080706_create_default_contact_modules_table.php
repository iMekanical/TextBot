<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('default_contact_modules', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->string('key');
            $table->string('translation_key');
            $table->tinyInteger('delible');
            $table->tinyInteger('active');
            $table->tinyInteger('migrated');
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('default_contact_modules');
    }
};
