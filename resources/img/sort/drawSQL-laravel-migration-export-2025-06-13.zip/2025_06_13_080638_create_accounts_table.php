<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('accounts', function (Blueprint $table) {
            $table->integer('id')->primary();
            $table->tinyInteger('has_access_to_paid_version_for_free');
            $table->string('api_key');
            $table->integer('number_of_invitations_sent')->nullable();
            $table->string('default_time_reminder_is_sent');
            $table->integer('default_gender_id')->nullable();
            $table->string('stripe_id')->index()->nullable();
            $table->string('card_brand')->nullable();
            $table->string('card_last_four')->nullable();
            $table->timestamp('trial_ends_at')->nullable();
            $table->tinyInteger('legacy_free_plan_unlimited_contacts');
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('accounts');
    }
};
