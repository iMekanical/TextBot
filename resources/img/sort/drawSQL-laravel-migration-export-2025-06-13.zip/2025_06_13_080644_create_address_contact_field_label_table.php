<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('address_contact_field_label', function (Blueprint $table) {
            $table->bigInteger('contact_field_label_id');
            $table->foreign('contact_field_label_id')->references('id')->on('contact_field_labels');
            $table->integer('address_id');
            $table->foreign('address_id')->references('id')->on('addresses');
            $table->integer('account_id');
            $table->foreign('account_id')->references('id')->on('accounts');
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('address_contact_field_label');
    }
};
