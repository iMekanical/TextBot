<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('gift_photo', function (Blueprint $table) {
            $table->integer('photo_id');
            $table->foreign('photo_id')->references('id')->on('photos');
            $table->integer('gift_id');
            $table->foreign('gift_id')->references('id')->on('gifts');
            $table->timestamp('created_at')->nullable();
            $table->timestamp('updated_at')->nullable();
            $table->primary(['photo_id', 'gift_id']);
        });

        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('gift_photo');
    }
};
